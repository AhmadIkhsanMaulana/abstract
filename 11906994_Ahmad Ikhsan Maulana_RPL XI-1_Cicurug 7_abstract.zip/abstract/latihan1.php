<?php 

	abstract class Pakaian {
		private $warna,
			    $ukuran,
			    $bahan,
				$harga,
		        $diskon = 0; 


		public function __construct($warna ="warna",$ukuran ="ukuran",$bahan = "bahan", $harga = 0) {
			$this->warna = $warna;
			$this->ukuran = $ukuran;
			$this->bahan = $bahan;
			$this->harga = $harga; 
		}

		public function setWarna($warna){
			$this->warna = $warna;
		}

		public function getWarna(){
			return $this->warna;
		}

		public function setUkuran($ukuran){
			$this->ukuran = $ukuran;
		}
		public function getUkuran (){
			return $this->ukuran;
		}

		public function setBahan($bahan){
			$this->bahan = $bahan;
		}
		public function getBahan(){
			return $this->bahan;
		}

		public function setDiskon ($diskon){
			$this->diskon = $diskon;
		}
		public function getDiskon(){
			return $this->diskon;
		}

		public function setHarga($harga){
			$this->harga = $harga;
		}

		public function getHarga(){
			return $this->harga - ($this->harga * $this->diskon / 100 );
		}

		public function getbuy(){
			return "$this->ukuran,$this->bahan";
		}

		abstract public function getinfoPakaian();

		public function getinfo(){
			$str = " {$this->warna} {$this->getbuy()} (RP.{$this->harga})";
			return $str;
		}
		

	}

	class celana extends Pakaian {
		public $jmlpcs;

		public function __construct( $warna ="warna",$ukuran ="ukuran",$bahan = "bahan",$harga = 0 ,$jmlpcs = 0 ){

			parent::__construct($warna , $ukuran , $bahan , $harga);

			$this->jmlpcs = $jmlpcs;
		}

		public function getinfoPakaian(){
			$str = "Celana : ". parent::getinfo()." ". "{$this->jmlpcs}/Pcs.";
			return $str;
		}
	}

	class baju extends Pakaian {
		public $jmlbuah;

		public function __construct( $warna ="warna",$ukuran ="ukuran",$bahan = "bahan",$harga = 0 ,$jmlbuah = 0  ){

			parent::__construct( $warna, $ukuran, $bahan, $harga);

			$this->jmlbuah = $jmlbuah;
		}

		public function getinfoPakaian(){
			$str = "Baju : " . parent::getinfo(). " ". "{$this->jmlbuah}/buah.";
			return $str;
		}

	}

	class cetakInfoPakaian {
		public $daftarPakaian = [];

		public function tambahPakaian( Pakaian $pakaian){
			$this->daftarPakaian[]  = $pakaian;
		}

		public function cetak(){
			$str = "DAFTAR PAKAIAN : <br>";

			foreach ($this->daftarPakaian as $pkn) {
				$str .= "- {$pkn->getinfoPakaian()} <br>";
			}
			return $str;
		}

	}

	$celana = new celana("Navy", "L", "Waterproof", 50000, 1);
	$baju = new baju("Hijau","XL", "Katun", 75000, 2);


	$cetakPakaian = new cetakInfoPakaian();
	$cetakPakaian->tambahPakaian($celana);
	$cetakPakaian->tambahPakaian ($baju);
	echo $cetakPakaian->cetak();



 